module.exports = {
    mongoProdURI: 'mongodb://todo-database:27018/todoapp',
};